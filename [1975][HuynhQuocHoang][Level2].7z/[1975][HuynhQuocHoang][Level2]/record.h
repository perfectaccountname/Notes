#include "r_macro.h"  /* System macro and standard type definition */

#define RUNNING 1
#define PAUSING 2

#define MODE2 2 // first record
#define MODE3 7 // last record
#define MODE1 6 // cho phep scroll up and down
#define NO_RECORD 0
typedef struct
{
	char ar[15];
}record;

extern unsigned int MODE;

extern unsigned int num_record;
extern unsigned int num;
extern unsigned int record_status;
extern int scroll;

void Return_LCD();
void check_record();
void scroll_up();
void scroll_down();
void save_record();
void shift_value();
void inc_time();
void reset_value();