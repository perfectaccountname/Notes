/******************************************************************************
* DISCLAIMER

* This software is supplied by Renesas Electronics Corporation and is only 
* intended for use with Renesas products. No other uses are authorized.

* This software is owned by Renesas Electronics Corporation and is protected under 
* all applicable laws, including copyright laws.

* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES 
* REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, 
* INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
* PARTICULAR PURPOSE AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY 
* DISCLAIMED.

* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES 
* FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS 
* AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

* Renesas reserves the right, without notice, to make changes to this 
* software and to discontinue the availability of this software.  
* By using this software, you agree to the additional terms and 
* conditions found by accessing the following link:
* http://www.renesas.com/disclaimer
******************************************************************************/
/* Copyright (C) 2015 Renesas Electronics Corporation. All rights reserved.  */
/******************************************************************************	
* File Name    : record.c
* Version      : 1.00
* Device(s)    : 
* Tool-Chain   : 
* H/W Platform : 
* Description  : 
******************************************************************************
* History : DD.MM.YYYY Version Description
*         : 01.07.2015 1.00    First Release
******************************************************************************/


/******************************************************************************
Includes   <System Includes> , "Project Includes"
******************************************************************************/
#include "r_macro.h"
#include "record.h"
#include <string.h>
#include "stdio.h"
#include "lcd.h"
#include "timer.h"
#include "check_button.h"
/******************************************************************************
Typedef definitions
******************************************************************************/

/******************************************************************************
Macro definitions
******************************************************************************/

/******************************************************************************
Imported global variables and functions (from other files)
******************************************************************************/
char pause[15] = "Pausing...";
char run[15] = "Running...";
char no_record[15] = "No record";
char first[15] = "First record";
char last[15] = "Last record";
unsigned int num_record;
unsigned int num;
unsigned int record_status;
int scroll;
record data[22];
char buff[15];
/******************************************************************************
Exported global variables and functions (to be accessed by other files)
******************************************************************************/

/******************************************************************************
Private global variables and functions
******************************************************************************/
unsigned int MODE;

/******************************************************************************
* Function Name: check_record
* Description  : This function use to check button whether press or not and change MODE when we press
* Arguments    : none
* Return Value : none
******************************************************************************/

void check_record()
{ 
	if(num_record == 0)
	{
		DisplayLCD(LCD_LINE1,(uint8_t *) no_record);
		record_status = NO_RECORD;
		t2s = 0;
	}
	else if((num_record < 7)&&(check == SW1))
	{
		DisplayLCD(LCD_LINE1,(uint8_t *) first);
		record_status = MODE2;
		t2s = 0;
	}
	else if((num_record < 7)&&(check == SW2))
	{
		DisplayLCD(LCD_LINE1,(uint8_t *) last);
		record_status = MODE3;
		t2s = 0;
	}
	else record_status = MODE1;
}

/******************************************************************************
* Function Name: scroll_up
* Description  : This function use to check button whether press or not and change MODE when we press
* Arguments    : none
* Return Value : none
******************************************************************************/

void scroll_up()
{ 
	int i,y;
	i=0;
	y=1;
	scroll++;
	if(scroll >= num_record-6)
	{
		scroll = num_record-6;
		DisplayLCD(LCD_LINE1 ,(uint8_t *)first);	
		record_status =MODE2 ;	//First Record	
		t2s  =0;
	}
	for(i=(num_record-5)-scroll;i<=num_record-scroll;i++)
	{
		unsigned char x = (unsigned char )(LCD_LINE2+8*y);
		DisplayLCD(x ,(uint8_t *) data[i].ar);
		y++;
	}
}

/******************************************************************************
* Function Name: scroll_up
* Description  : This function use to check button whether press or not and change MODE when we press
* Arguments    : none
* Return Value : none
******************************************************************************/
void scroll_down()
{ 
	int i,y;
	i=0;
	y=1;
	scroll--;
	if(scroll <=0)
	{
		scroll = 0;
		DisplayLCD(LCD_LINE1 ,(uint8_t *)last);	
		record_status =MODE3 ;		
		t2s  =0;
	}
	for(i=num_record-5-scroll;i<=num_record-scroll;i++)
	{
		unsigned char x = (unsigned char) (LCD_LINE2+8*y);
		DisplayLCD(x ,(uint8_t *) data[i].ar);
		y++;
	}
}

/******************************************************************************
* Function Name: save_record
* Description  : This function use to check button whether press or not and change MODE when we press
* Arguments    : none
* Return Value : none
******************************************************************************/
void save_record()
{
	int i;
	int y;
	num_record++;
	num++;
	scroll =0;	
	if (num_record >21)
	{
		num_record =21;
	}
	sprintf( data[num_record].ar , "#%d:%0.2d:%0.2d:%0.2d",num, g_time.minute , g_time.second,g_time.centi_second);
	if (num_record <7)
	{
		for(i =1 ; i <= num_record; i++)
		{	
			unsigned char x = (unsigned char)(LCD_LINE2 + i*8);
			DisplayLCD(x,(uint8_t *)data[i].ar);
		}
	}
	if (num_record >=7 && num_record <=20)/*if number of record >=6 till number of record <= max number*/
	{
		y=1;
		for(i = num_record -6 ; i < num_record; i++)
		{	
			unsigned char x = (unsigned char)(LCD_LINE2 + y*8);
			DisplayLCD(x,(uint8_t *)data[i+1].ar);
			y++;
			
		}
	}
	if (num_record >20)	/*if number of record > max number*/
	{ 
		y=1;
		shift_value();
		for(i = num_record -6 ; i < num_record; i++)
		{	
			unsigned char x = (unsigned char)(LCD_LINE2 + y*8);
			DisplayLCD(x,(uint8_t *)data[i].ar);
			y++;
				
		}
		num_record =20;
	}
	
}
void shift_value()
{
	int i;
	for(i=1;i<21;i++)
	{ 
		strcpy(data[i].ar,data[i+1].ar);
	}
}

/******************************************************************************
* Function Name: check_record
* Description  : This function use to check button whether press or not and change MODE when we press
* Arguments    : none
* Return Value : none
******************************************************************************/

void Return_LCD()
{ 
	if(MODE == RUNNING)
		DisplayLCD(LCD_LINE1,(uint8_t *)run);
	else if(MODE == PAUSING)
		DisplayLCD(LCD_LINE1,(uint8_t *)pause);
}
void inc_time()
{
		centi_sec_flag=0;
		g_time.centi_second += 10;
		if(100 == g_time.centi_second)
		{
			g_time.centi_second=0;
			g_time.second++;
			if(g_time.second==60)
			{
				g_time.second=0;
				g_time.minute++;
				if(60==g_time.minute)
					g_time.minute=0;
			}
		}
		sprintf(buff, "%0.2d:%0.2d:%0.2d",g_time.minute,g_time.second,g_time.centi_second);
		DisplayLCD(LCD_LINE2+1,(uint8_t *) buff);
}
void reset_value()
{
	g_time.centi_second=0;
	g_time.second=0;
	g_time.minute=0;
	sprintf(buff, "%0.2d:%0.2d:%0.2d",g_time.minute,g_time.second,g_time.centi_second);
	DisplayLCD(LCD_LINE2+1,(uint8_t *) buff);
}
/******************************************************************************
End of file
******************************************************************************/