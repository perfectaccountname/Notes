


#pragma interrupt INTAD adc_interrupt

#include "adc.h"


static volatile uint16_t adc_buffer_value = 0;


/***********************************************************************************************************************
* Function Name: adc_interrupt
* Description  : This function is INTAD interrupt service routine.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
__interrupt static void adc_interrupt(void)
{
	adc_buffer_value = (ADCR>>6);
}

static uint16_t _round(float adcresult){
	uint16_t temp;	

	if(adcresult > (((uint16_t)adcresult)+0.5f)){
		temp =  ((uint16_t)(adcresult+0.5f));
	}
	else{
		temp = (uint16_t)adcresult;
	}	
	return temp;
}
/***********************************************************************************************************************
* Function Name: ADC_Create
* Description  : This function initializes the AD converter.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void adc_Create(void)
{
	ADCEN = 1U;            			/* supply AD clock */
	ADM0 = 0x00;                     	/* disable AD conversion and clear ADM0 register */
	ADMK = 1U;                        	/* disable INTAD interrupt */
	ADIF = 0U;                        	/* clear INTAD interrupt flag */
    /* Set INTAD level2 priority */
	ADPR1 = 1U;
	ADPR0 = 0U;
    
    /* Set ANI8 pin as analog input */
    // set the pin PM150 as input mode. configure the ADPC register(bydefault this reg = 0, mean all pin in this reg config 
    // 									(156-150  27-20)   is use as analog input
	P15_bit.no0 = 1U;	//ADPC default 0; analog
    // bit adcs admd fr[5:3] lv[2:1] adce	// start/stop conversion, sel/scan mode,conversion clock, en/stop volt compare
	ADM0 = ADMODE0_ADCSELECTMODE|ADMODE0_CONVERSIONCLK_64|ADMODE0_NORMAL2;	 
    // ADTMD[7:6] ADSCM - - - ADTRS[1:0] // trigger mode, conversion mode, trigger source
	ADM1 = ADMODE1_SWTGR|ADMODE1_SEQ_CONV;
    // ADREFP[7:6] ADREFM - ADRCK AWC - ADTYP		CKKBT  low< ADCRH <up limit -> output INTAD
	ADM2 = ADMODE2_PREF_VDD|ADMODE2_NREF_VSS|ADMODE2_CKBT|ADMODE2_RES10BIT;	
    // analog channel specification chose the input analog channel to the ADC
	ADS = ADSEL_CH8;		
	ADUL = 0x0FF;	// upper limit
	ADLL = 0x00;	// lower limit                    
}


/***********************************************************************************************************************
* Function Name:adc_Start
* Description  : This function starts the AD converter.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void adc_Start(void)
{
	ADIF = 0U;  /* clear INTAD interrupt flag */
	ADMK = 0U;  /* enable INTAD interrupt */
	ADCS = 1U;  /* enable AD conversion */
}


/***********************************************************************************************************************
* Function Name:adc_Stop
* Description  : This function stops the AD converter.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void adc_Stop(void)
{
	ADCS = 0U;  /* disable AD conversion */
	ADMK = 1U;  /* disable INTAD interrupt */
	ADIF = 0U;  /* clear INTAD interrupt flag */
}


/***********************************************************************************************************************
* Function Name:adc_Set_OperationOn
* Description  : This function enables comparator operation.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void adc_setOperationOn(void)
{
    	ADCE = 1U;  /* enable AD comparator */	// ADCS 0 ADCE 0: stop mode, no consumption power
}						// ADCS 0 ADCE 1: stanby mode,only AD comparator comsumption 
						// ADCS 1 ADCE 1: run conversion / ADCS1 ADCE 0 << prohibited					

/***********************************************************************************************************************
* Function Name:adc_Set_OperationOff
* Description  : This function stops comparator operation.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void adc_setOperationOff(void)
{
    	ADCE = 0U;  /* disable AD comparator */
}


/***********************************************************************************************************************
* Function Name: adc_getResultAnalog
* Description  : This function returns the conversion result analog(consider the error) to the buffer.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
float adc_getResultAnalog(void)
{
	static uint16_t currentResult = 0;
	uint16_t newResult;
	int16_t temp = 0;
	float rawresult;
	
	newResult = adc_buffer_value;
	
	temp =(int16_t)newResult-(int16_t)currentResult;
	if(temp<0){
		temp = -temp;		//<< some problem with abs??
	}
	if((float)temp >ADC_ERROR){	
		currentResult = newResult;
	}
	rawresult = ((float)currentResult)*ADC_ANALOG_MAX/ADC_DIGITAL_MAX;
	return rawresult;
}


/***********************************************************************************************************************
* Function Name: adc_getResult
* Description  : return the digital value scale back to 0-999.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
uint16_t adc_getResult(void){
	static uint16_t currentResult = 0;
	uint16_t newResult;
	int16_t temp = 0;
	
	newResult = adc_buffer_value;
	
	temp =(int16_t)newResult-(int16_t)currentResult;
	if(temp<0){
		temp = -temp;		//<< some problem with abs??
	}
	if(temp >ADC_ERROR){	
		currentResult = newResult;
	}
	
	currentResult = _round( (((float)currentResult/1023.0f) * 999.0f) );
	
	return currentResult;
}



/******************************************************************************
End of file
******************************************************************************/
