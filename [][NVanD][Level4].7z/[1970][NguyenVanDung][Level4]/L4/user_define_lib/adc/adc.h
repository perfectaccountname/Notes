

#ifndef __ADC_H__
#define __ADC_H__

#include "include.h"


void adc_Create(void);
void adc_Start(void);
void adc_Stop(void);
void adc_setOperationOn(void);
void adc_setOperationOff(void);
float adc_getResultAnalog(void);
uint16_t adc_getResult(void);

#endif

