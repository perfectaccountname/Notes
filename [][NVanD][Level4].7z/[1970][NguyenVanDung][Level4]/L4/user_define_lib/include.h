

#ifndef __INCLUDE_H__
#define __INCLUDE_H__


#include "r_macro.h"
#include "r_spi_if.h" /* SPI driver interface */
#include "lcd.h"      /* LCD driver interface */
#include "iodefine.h"
#include "iodefine_ext.h"

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>


#define TRUE 0x1U
#define FALSE 0x0U
#define ASCINUMBER 0x30U


/*************** LCD Display define *****************/
#define LCD_NUM_DISPLAY_LINE 8U
#define LCD_LINE_LEN 8U
#define LCD_MAX_CHAR_PER_LINE 12U

#define LCD_COLUMN1 1U
#define LCD_COLUMN2 2U
#define LCD_COLUMN3 3U
#define LCD_COLUMN4 4U
#define LCD_COLUMN5 5U
#define LCD_COLUMN6 6U

#define ERROR_STR "UART Err"

#define FRAME_TXT_OFFSET (4U)
/****************************************************/


/**************Switch Polling define*****************/
#define numStateRequired 60U
#define SW1_MASK 0x40
#define SW2_MASK 0x10
#define SW3_MASK 0x20
#define ALL3SW_MASK 0x70

// only use 1 switch 3, use other method for effeciency

typedef struct {
	uint8_t state[numStateRequired];
	uint8_t index;
	uint8_t lastPinState;
	uint8_t currentPinState;
	uint8_t changedPins;		// detect negative edge;
} portDebounce;
/***************************************************/


/*********************LED define*********************/
#define GPIO_PIN0 0x01
#define GPIO_PIN1 0x02
#define GPIO_PIN2 0x04
#define GPIO_PIN3 0x08
#define GPIO_PIN4 0x10
#define GPIO_PIN5 0x20
#define GPIO_PIN6 0x40
#define GPIO_PIN7 0x80

#define NUMBERLEDS 13U

#define ADPC_FORMAT_DIGI_152_156 0x0B

#define LEDOFFSET 3U

#define PORT4 (volatile unsigned char *)0xFFF04
#define PORT6 (volatile unsigned char *)0xFFF06
#define PORT10 (volatile unsigned char *)0xFFF0A
#define PORT15 (volatile unsigned char *)0xFFF0F

#define ON_STATE 0x1U
#define OFF_STATE 0x0U

typedef struct {
	volatile unsigned char *port;
	uint8_t ON;
	uint8_t OFF;
} myled;

typedef struct {
	myled arr[NUMBERLEDS];
	uint16_t arrayStatus;
} myledarray;

/****************************************************/


/*********************ADC define*********************/
#define ADC_DONE	(0x01U)
#define ADC_PENDING	(0x02U)

#define ADMODE0_ADCSTART 0x80
#define ADMODE0_ADCSELECTMODE 0x00
#define ADMODE0_ADCSCANMODE 0x40
#define ADMODE0_ADCENABLE_VOLT_CP 0x01

#define ADMODE0_CONVERSIONCLK_64 0x00
#define ADMODE0_CONVERSIONCLK_32 0x08
#define ADMODE0_CONVERSIONCLK_16 0x10
#define ADMODE0_CONVERSIONCLK_8 0x18
#define ADMODE0_CONVERSIONCLK_5 0x20
#define ADMODE0_CONVERSIONCLK_4 0x30
#define ADMODE0_CONVERSIONCLK_2 0x38

#define ADMODE0_NORMAL1 0x00
#define ADMODE0_NORMAL2 0x02
#define ADMODE0_LOWV1 0x04
#define ADMODE0_LOWV2 0x06

#define ADMODE1_SWTGR 0x00
#define ADMODE1_SEQ_CONV 0x00
#define ADMODE1_ONESHOT_CONV 0x20

#define ADMODE2_PREF_VDD 0x00
#define ADMODE2_PREF_P20 0x40
#define ADMODE2_PREF_INTERNALREF 0x80
#define ADMODE2_NREF_VSS 0x00
#define ADMODE2_NREF_P21 0x20
#define ADMODE2_CKBT 0x00
#define ADMODE2_NOSNOOZE 0x00
#define ADMODE2_RES10BIT 0x00
#define ADMODE2_RES8BIT 0x01

#define ADSEL_CH8 0x8

#define ADC_DIGITAL_MAX 1023U
#define ADC_SCALE_VALUE 999U
#define ADC_ANALOG_MAX (3.3f)
#define ADC_ERROR (2U)

/****************************************************/


/**********************Timer define*****************/
// Timer unit 0 channel 0 for polling interval
#define TAU00_TPS_PRESCALE_500KHZ 0x0006
#define TAU00_TPS_PRESCALE_62_5KHZ 0x0009
#define TAU00_TMR_OPCLK_CK00  0x0000		//bit15-16
#define TAU00_TMR_COUNTCLK_CKS000 0x0000	//bit12
#define TAU00_TMR_STARTTRG_SW 0x0000		//bit10-8
#define TAU00_TMR_MODE_ITCD_NOINTSTART 0x0000	//bit0-3	no interrupt when interval timer start countdown and timeroutput not inverse
#define TAU00_TDR_INTERVAL_VALUE 12500U

#define INTERVAL2S 200U

//-------------------------------------//
// 12bit- Interval Timer 
#define IT_FSUB_SELECT 0x80
#define IT_FIL_SELECT 0x10
#define IT_COUNT_STATED 0x8000
#define IT_COUNT_STOP 0x0EFFF
#define IT_VALUE 3000U

#define IT_TIMER_COUNT_INTERVAL 10U

/***************************************************/


/**********************UART define******************/

#define UART_SPSCK0_PRESCALE_8MHZ (0x0002U)	// 8MHZ if the system clock is 32MHz
#define UART_SPSCK1_PRESCALE_8MHZ (0x0020U)

#define UART_TX1 (0x04U)
#define UART_RX1 (0x08U)

#define UART_SMR_SEL_CK0 (0x0020U)
#define UART_SMR_SEL_CK1 (0x8020U)
#define UART_SMR_TCLK_CK (0x0020U)
#define UART_SMR_STRG_SW (0x0020U)
#define UART_SMR_STRG_RXEDGE (0x0120U)		// set this for RX
#define UART_SMR_STARTBIT_FALL_EDGE (0x0020U)
#define UART_SMR_STARTBIT_RIS_EDGE (0x0060U)
#define UART_SMR_MDUART (0x0022U)
#define UART_SMR_MD_TXEND (0x0020U)
#define UART_SMR_MD_BUFFEMPTY (0x0021U)

#define UART_SCR_RX (0x4004U)
#define UART_SCR_TX (0x8004U)
#define UART_SCR_ERRORINT_DIS (0x0004U)
#define UART_SCR_ERRORINT_EN (0x0404U)
#define UART_SCR_PARITY_NONE (0x0004U)
#define UART_SCR_PARITY_ZERO (0x0104U)
#define UART_SCR_PARITY_EVEN (0x0204U)
#define UART_SCR_PARITY_ODD (0x0304U)
#define UART_SCR_LSB (0x0084U)
#define UART_SCR_MSB (0x0004U)
#define UART_SCR_SBIT_NONE (0x0004U)
#define UART_SCR_SBIT_ONE (0x0014U)
#define UART_SCR_SBIT_TWO (0x0024U)	// TX only
#define UART_SCR_DL_NINE (0x0005U)
#define UART_SCR_DL_SEVEN (0x0006U)
#define UART_SCR_DL_EIGHT (0x0007U)
									//(0x67)<<9  . result shiftleft 9.
#define UART_BAUD_VALUE (0x0CE00U)   // clock prescaler = baudrate *(2+2*UART_BAUD_VALUE[15:9 bit of SDR])

#define UART_SIR_FLAGCLEAR_FE (0x0004U)
#define UART_SIR_FLAGCLEAR_PE (0x0002U)
#define UART_SIR_FLAGCLEAR_OVE (0x0001U)

#define ERROR_MASK (0x0007U)
#define ERROR_OVERRUN (0x1U)
#define ERROR_PARITY (0x2U)
#define ERROR_FRAME (0x3U)

#define UART_TIMEOUT (1000U)

#define MAXFRAMESIZE (25U)
#define bufferSIZE (50U)
#define IDCODE (1970U)

typedef enum{
	msgLED = 'L',
	msgADC = 'A',
	msgTXT = 'T'
} msgType;

typedef struct {
	char data[bufferSIZE]; 
	uint8_t dataCount;
	int8_t front;
	int8_t rear;
} uartBuffer;

typedef enum{
	msg_err_LedNo = 10U,
	msg_err_LedState,
	msg_err_LCDLine,
	msg_err_LCDContent,
	msg_err_Len,
	msg_err_Format
} msgErrType;

#define INIT_VALUE (-1)
#define STATE_NORMAL (0x01U)
#define STATE_ERROR (0x02U)
#define STATE_SUSPEND (0x03U)
/***************************************************/


/*****************GLOBAL VARIABLE*******************/

extern uartBuffer RxBuffer;

extern uint8_t g_flag_RXerror;		// uart reception error
extern uint8_t g_flag_InvalidMsg;	// invalid data frame

extern msgErrType g_MSGerrorStatus;
extern uint8_t g_RXerrorStatus;		// 1 2 4 -> overrun parity framing

extern myledarray LEDarray;

extern uint8_t state;
/***************************************************/
#endif