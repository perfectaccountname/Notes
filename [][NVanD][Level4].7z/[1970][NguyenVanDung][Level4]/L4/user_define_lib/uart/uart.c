
/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/
#pragma interrupt INTSR1 isr_UARTRX
#pragma interrupt INTSRE1 isr_UARTERROR
/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "uart.h"

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
uartBuffer RxBuffer={0};
uint8_t g_flag_RXerror = FALSE;
uint8_t g_RXerrorStatus = FALSE;

uint8_t g_flag_InvalidMsg = FALSE;
msgErrType g_MSGerrorStatus = FALSE;
/***********************************************************************************************************************
* Function Name: isr_UARTRX
* Description  : interrupt service UART1 receive.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
__interrupt static void isr_UARTRX(void){
	uint8_t temp;
	EI();
	// write data to buffer, buffer will be processed in main.
	temp = RXD1;
	if(state == STATE_NORMAL){
		uart_bufferWrite(temp);
	}
}


/***********************************************************************************************************************
* Function Name: isr_UARTERROR
* Description  : interrupt serivice UART1 receive error.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
__interrupt static void isr_UARTERROR(void){
	EI();
	// set the rxerror flag, change state to errorstate and get and clear the error status
	g_flag_RXerror = TRUE;
	state = STATE_ERROR; 
	g_RXerrorStatus = (uint8_t)(SSR03&ERROR_MASK);
	SIR03 = (SIR03&g_RXerrorStatus);
}

/***********************************************************************************************************************
* Function Name: _Transmit
* Description  : This function transmit number of data bytes, using UART.
* Arguments    : Transmission data pointer, data length.
* Return Value : None
***********************************************************************************************************************/
static void _Transmit(char* tx_ptr, int len)
{
	uint8_t i = 0;
	uint16_t TimeOut = 0;

	for(i = 0; i < len; i++)
	{
		TXD1 = *(tx_ptr + i);
		TimeOut = UART_TIMEOUT;
		while((STIF1 == 0)||(TimeOut--));
		STIF1 = 0;
	}
}


/***********************************************************************************************************************
* Function Name: _error
* Description  : change state update error status.
* Arguments    : msgErrType _err.
* Return Value : None
***********************************************************************************************************************/
static void _error(msgErrType _err){
	g_flag_InvalidMsg = TRUE;
	g_MSGerrorStatus = _err;	
	state = STATE_ERROR;
}


/***********************************************************************************************************************
* Function Name: isDigit
* Description  : check if char is digit char.
* Arguments    : char c.
* Return Value : TRUE or FALSE
***********************************************************************************************************************/
static uint8_t isDigit( char c){
	if( (c>='0') && (c<='9')){
		return TRUE;	
	}
	else{
		return FALSE;
	}
}


/***********************************************************************************************************************
* Function Name: isAlphabet
* Description  : check if char is alphabet char.
* Arguments    : char c.
* Return Value : TRUE or FALSE
***********************************************************************************************************************/
static uint8_t isAlphabet( char c){
	if( ((c>='a') && (c<='z')) ||((c>='A') && (c<='Z'))){
		return TRUE;	
	}
	else{
		return FALSE;
	}
}
/***********************************************************************************************************************
* Function Name: uart_Init
* Description  : This function initializes the UART1.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void uart_Init(void){
	SAU0EN = 1U;   				// enable clock input to module Serial array unit
	NOP();
	NOP();					// cautions 2: page 701
	NOP();
	NOP();
	SPS0 = (UART_SPSCK0_PRESCALE_8MHZ	//select clock for SAU
	|UART_SPSCK1_PRESCALE_8MHZ);		// system clock 32MHz prescale  8MHz

	ST0 = UART_TX1|UART_RX1;	// uart1(channel 2-3 of unit 0) 2::TX 3::RX     
	
	// Transfer
	STMK1 = 1U;      			// disable INTST1 interrupt service
	STIF1 = 0U;      			// clear INTST1 interrupt flag 
	// Receive
	SRMK1 = 1U;      			// disable INTSR1 interrupt service
	SRIF1 = 0U;      			// clear INTSR1 interrupt flag 
	// Receive error
	SREMK1 = 1U;     			// disable INTSRE1 interrupt service
	SREIF1 = 0U;     			// clear INTSRE1 interrupt flag 
	
	// Priority level 0, 1, 2, 3 = PR[0:1], lower number = higher priority
	// Set INTSR1 data receive interrupt priority 
	SRPR11 = 0U;
	SRPR01 = 1U;
	// Set INTSRE1 error receive interrupt priority 0 highest,receive 1 2nd, and transfer 2 in 3rd
	SREPR11 = 0U;
	SREPR01 = 0U;

	// Send uart1-TX ( unit0-channel 2)--------------------------------//
	
	// serial mode register
	SMR02 = (UART_SMR_SEL_CK0|UART_SMR_TCLK_CK|UART_SMR_STRG_SW|UART_SMR_STARTBIT_FALL_EDGE|UART_SMR_MDUART|UART_SMR_MD_TXEND);
	
	// serial communication operation reg
	//Transmit, NOT mask error interrupt, no parity, LSB first, stop bit 1 bit, data length 8 bit
	SCR02 = UART_SCR_TX|UART_SCR_ERRORINT_DIS|UART_SCR_PARITY_ODD|UART_SCR_LSB|UART_SCR_SBIT_ONE|UART_SCR_DL_EIGHT;  
	
	// serial data reg: setup baudrate and data send  clock uart prescale: 8MHz: baudrate 38400 // value in 0xCE00
	SDR02 |= UART_BAUD_VALUE;  	
  
	//----------------------------------------------------------------//
	
	// receive uart1-RX ( unit0-channel3)-----------------------------//
	
	// noise enable for RXD1
	NFEN0 = 0x04U;  
	
	// clear flag trigger 
	SIR03 = UART_SIR_FLAGCLEAR_FE|UART_SIR_FLAGCLEAR_PE|UART_SIR_FLAGCLEAR_OVE;     
	
	SMR03 = (UART_SMR_SEL_CK0|UART_SMR_TCLK_CK|UART_SMR_STRG_RXEDGE|UART_SMR_STARTBIT_FALL_EDGE|UART_SMR_MDUART);
	
	// Receive, mask error interrupt, no parity, LSB first, stop bit 1 bit, data length 8 bit
	SCR03 = UART_SCR_RX|UART_SCR_ERRORINT_EN|UART_SCR_PARITY_ODD|UART_SCR_LSB|UART_SCR_SBIT_ONE|UART_SCR_DL_EIGHT; 
	
	// serial data reg: setup baudrate and data send  clock uart prescale: 8MHz: baudrate 38400 // value in 0xCE00
	SDR03 |= UART_BAUD_VALUE;
	//----------------------------------------------------------------//
	
	SO0 |= UART_TX1;     	// output level normal 
	SOL0 &= (~UART_TX1);    // output level normal 
	SOE0 |= UART_TX1;    	// enable UART1 output 

	// Port inint for UART communicate
	PIOR0 &= 0x0DF;		// PIOR0 hardware manual 248, bit5 = 0, tx rx p02 p03
	
	// set RxD1 pin
	PMC0 &= ~GPIO_PIN3;	// digital I/O select
	PM0 |= GPIO_PIN3;	// output buffer off(in mode)
	// Set TxD1 pin 
	PMC0 &= ~GPIO_PIN2;	// digital I/O select
	P0 |= GPIO_PIN2;	// level output high?
	PM0 &= ~GPIO_PIN2;	// output buffer on(out mode)
	
	uart_bufferReset();	
}


/***********************************************************************************************************************
* Function Name: uart_Start
* Description  : This function start UART1 operation.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void uart_Start(void){
	
	SO0 |= UART_TX1;     	// output level normal 
	SOL0 &= (~UART_TX1);    // enable UART1 output  
	
	SS0 |= UART_TX1|UART_RX1;   		// enable UART1 receive and transmit 
    
	// Transfer
	STMK1 = 1U;      			// disable INTST1 interrupt service
	STIF1 = 0U;      			// clear INTST1 interrupt flag 
	// Receive
	SRMK1 = 0U;      			// enable INTSR1 interrupt service
	SRIF1 = 0U;      			// clear INTSR1 interrupt flag 
	// Receive error
	SREMK1 = 0U;     			// enable INTSRE1 interrupt service
	SREIF1 = 0U;     			// clear INTSRE1 interrupt flag 
}


/***********************************************************************************************************************
* Function Name: uart_Stop
* Description  : This function stop UART1 operation.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void uart_Stop(void){
	ST0 |= UART_TX1|UART_RX1;     		// stop UART1 receive and transmit 
	SOE0 &= ~UART_TX1;    			// stop UART1 output 
    
	// Transfer
	STMK1 = 1U;      			// disable INTST1 interrupt service
	STIF1 = 0U;      			// clear INTST1 interrupt flag 
	// Receive
	SRMK1 = 1U;      			// disable INTSR1 interrupt service
	SRIF1 = 0U;      			// clear INTSR1 interrupt flag 
	// Receive error
	SREMK1 = 1U;     			// disable INTSRE1 interrupt service
	SREIF1 = 0U;     			// clear INTSRE1 interrupt flag 
}
	

/***********************************************************************************************************************
* Function Name: uart_bufferWrite
* Description  : write data to RXbuffer
* Arguments    : uint8_t data
* Return Value : None
***********************************************************************************************************************/
uint8_t uart_bufferWrite( uint8_t data){

	if(uart_bufferIsFull() == TRUE){
		return FALSE;	
	}
	if(RxBuffer.rear == INIT_VALUE){
		RxBuffer.rear = 0U;
	}
	else{
		RxBuffer.rear = (RxBuffer.rear+1)%bufferSIZE;
	}
	RxBuffer.data[RxBuffer.rear] = data;
	RxBuffer.dataCount++;
	return TRUE;
}


/***********************************************************************************************************************
* Function Name: uart_bufferRead
* Description  : read data from RXbuffer
* Arguments    : None
* Return Value : uint8_t data
***********************************************************************************************************************/
uint8_t uart_bufferRead(void){
	uint8_t temp;
	if(uart_bufferIsEmpty() == TRUE){
		return FALSE;
	}
	if(INIT_VALUE == RxBuffer.front){
		RxBuffer.front=0U;
	}
	else{
		RxBuffer.front = (RxBuffer.front+1)%bufferSIZE;
	}
	temp=RxBuffer.data[RxBuffer.front];
	RxBuffer.dataCount--;

	return temp;
}


/***********************************************************************************************************************
* Function Name: uart_bufferIsFull
* Description  : check if RXbuffer is full or not
* Arguments    : None
* Return Value : TRUE or FALSE
***********************************************************************************************************************/
uint8_t uart_bufferIsFull(void){
	if(RxBuffer.rear == ((bufferSIZE + RxBuffer.front - 1)%bufferSIZE)){
		return TRUE;
	}
	else{
		return FALSE;
	}
}


/***********************************************************************************************************************
* Function Name: uart_bufferIsEmpty
* Description  : check if RXbuffer is empty or not
* Arguments    : None
* Return Value : TRUE or FALSE
***********************************************************************************************************************/
uint8_t uart_bufferIsEmpty(void){
	if(RxBuffer.rear == RxBuffer.front){
		return TRUE;
	}
	else{
		return FALSE;	
	}
}


/***********************************************************************************************************************
* Function Name: uart_bufferReset
* Description  : reset the RXbuffer
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void uart_bufferReset(void){
	memset(&RxBuffer.data[0],0U,bufferSIZE+3);
	RxBuffer.dataCount = 0U;
	RxBuffer.front = INIT_VALUE;
	RxBuffer.rear = INIT_VALUE;	
}


/***********************************************************************************************************************
* Function Name: uart_processData
* Description  : in normal state, system keep process the data in RXbuffer
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void uart_processData(void){
	// if buffer have data, then process it.
	uint8_t datalen = 0; // this is framelen - 2(for start and stop char '$' '^')
	char temp;
	char *tempdata;
	// MAXFRAMESIZE = 25 is TEXT frame//
	tempdata = (char *)malloc(MAXFRAMESIZE-2U); // minus 2 for the start char '$' end char '^'
	
	// when buffer have data and in while loop to process, new data still can write into buffer
	// by interrupt RX, and timer interrrupt still can send monitoring msg up to pc
	while(uart_bufferIsEmpty() == FALSE){
		// ignore all the random signal may get from data line, start process when have '$' open char
		while(uart_bufferRead() != '$'){
			// if all the data receive when in normal mode is random char not start with '$'
			// then read those data out the buffer and when buffer empty return out this process function 
			if(uart_bufferIsEmpty() == TRUE){
				free(tempdata);	
				return ;
			}
		}
		
		// receive the start char '$' the while loop above end
		// then read the msg data out buffer till 
		// the end char '^' and break out current loop
		// if the datalen counter reach more then MAXFRAMESIZE-2U 
		// return from this function with invalid msg error frame length
		while(TRUE){
			temp = uart_bufferRead();
			if(temp == FALSE){// buffer is empty normore new data but frame not done yet
				uint16_t j = 10000;
				while(j--);
				if(uart_bufferIsEmpty() == TRUE){	// time out, not receive new data of this frame for too long
					// time out error??
					
					free(tempdata);	
					return ;
				}
				else{
					temp = uart_bufferRead();
				}
			}
			if(temp == '^'){
				break;	// end frame char receive, break get data while loop
			}
			if(datalen>=(MAXFRAMESIZE-2U)){	// datalen counter reach max value but still no end char '^'
				_error(msg_err_Len);// error msg len occurs
				free(tempdata);	
				return;
			}
			*(tempdata+datalen) = temp;
			datalen++;	// i = data length	
		}
		
		// read all the data ok( start with char '$'  end with char '^' and no invalid data len
		// next process is check format, valid led number, led state, lcd line ,text content
		// after done process break out hte while loop, free the tempdata
		switch (tempdata[0]){
			case msgLED:	// led frame with out start and end char could have length 5-6		      
				// second , could be at 3 or 4 pos, if none of them was , then error	 
				// check format 
				if((tempdata[1]!=',') || (tempdata[datalen-2U]!=',')){
					_error(msg_err_Format);
				}
				// check led pos and state.
				else{
					uint8_t pos,ledstate;
					if(datalen == 5U){
						pos = (tempdata[2]-ASCINUMBER);
						ledstate = (tempdata[4]-ASCINUMBER);
					}
					else{
						pos = (tempdata[2]-ASCINUMBER)*10 + (tempdata[3]-ASCINUMBER);
						ledstate = (tempdata[5]-ASCINUMBER);
					}
					
					if((pos<3U) || (pos>15U)){
						_error(msg_err_LedNo);
					}
					else if((ledstate!= ON_STATE) && (ledstate!=OFF_STATE)){
						_error(msg_err_LedState);
					}
					else{
						led_Control(pos,ledstate);	
					}
				}
			break;
			case msgTXT:
				if((tempdata[1]!=',') || (tempdata[3]!=',')){
					_error(msg_err_Format);
				}
				// check line, check txt string
				// T,<linenumber>,<textstring>
				// 01     2      3 4
				else{
					uint8_t linenum,k,txttest = 0x0;
					linenum = tempdata[2]-ASCINUMBER;
					for(k = FRAME_TXT_OFFSET;k<datalen;k++){ // text string start from 4-end
						if((!isDigit(tempdata[k])) && (!isAlphabet(tempdata[k]))){
							txttest = 0x1;
							break;
						}						
					}
					if((linenum<1U)||(linenum>8U)){
						_error(msg_err_LCDLine);
					}
					else if(txttest == 0x1){
						_error(msg_err_LCDContent);
					}
					else{
						uint8_t k;
						char first[LCD_MAX_CHAR_PER_LINE];
						char second[LCD_MAX_CHAR_PER_LINE];
						memset(first,' ',LCD_MAX_CHAR_PER_LINE);
						memset(second,' ',LCD_MAX_CHAR_PER_LINE);
						
						if((datalen-FRAME_TXT_OFFSET)>LCD_MAX_CHAR_PER_LINE){
							for(k = 0; k<LCD_MAX_CHAR_PER_LINE;k++){
								first[k] = tempdata[k+FRAME_TXT_OFFSET];	
							}
							for(k = LCD_MAX_CHAR_PER_LINE; k<(datalen-FRAME_TXT_OFFSET);k++){
								second[k-LCD_MAX_CHAR_PER_LINE] = tempdata[k+FRAME_TXT_OFFSET];	
							}
							DisplayLCD((linenum-1U)*LCD_LINE_LEN,(uint8_t*)first,LCD_MAX_CHAR_PER_LINE);
							
							DisplayLCD((linenum)*LCD_LINE_LEN,(uint8_t*)second,LCD_MAX_CHAR_PER_LINE);//datalen-FRAME_TXT_OFFSET-LCD_MAX_CHAR_PER_LINE);
						}
						else{
							for(k = 0; k<(datalen-FRAME_TXT_OFFSET);k++){
								first[k] = tempdata[k+FRAME_TXT_OFFSET];	
							}
							DisplayLCD((linenum-1U)*LCD_LINE_LEN,(uint8_t*)first,LCD_MAX_CHAR_PER_LINE);//datalen-FRAME_TXT_OFFSET);
															           // LCD bug have cross line in screen when use 
																   // GlyphEraseBlock func
						}
					}
				}
			break;
			default:
				// not msg txt or led then error format
				_error(msg_err_Format);
			break;
		}
		// break out process frame while loop 
		break;
	}	
	
	free(tempdata);		
}


/***********************************************************************************************************************
* Function Name: uart_Send
* Description  : get the data and msg type, create frame and transfer
* Arguments    : uint16_t _ID, msgType _type, uint16_t _value
* Return Value : None
***********************************************************************************************************************/
void uart_Send(uint16_t _ID, msgType _type, uint16_t _value){
	static char frameA[11] ={'$',0,0,0,0,',','A',0,0,0,'^'}; 
	static char frameL[12] ={'$',0,0,0,0,',','L',0,0,0,0,'^'};
	uint8_t i = 0, maskedvalue = 0;
	uint16_t temp = _ID; uint16_t mask = 0x0F000;

	if(_type == msgLED){
		for(i = 4;i>0;i--){
			frameL[i] = (uint8_t)(temp%10 + ASCINUMBER);
			temp = temp/10;
		}
		for(i = 0;i<4;i++){ 
			maskedvalue = (uint8_t)((_value&mask)>>(12-i*4));
			if(maskedvalue < 0x0a){
				frameL[7+i] = maskedvalue+ASCINUMBER;
			}
			else{
				frameL[7+i] = maskedvalue+ASCINUMBER+7U;
			}
			mask = mask>>4;
		}
		_Transmit(frameL,12);
	}
	else if(_type == msgADC){
		for(i = 4;i>0;i--){
			frameA[i] = (uint8_t)(temp%10 + ASCINUMBER);
			temp = temp/10;
		}
		temp = _value;
		for(i = 3;i>0;i--){ 
			frameA[6+i] = (uint8_t)(temp%10 + ASCINUMBER);
			temp = temp/10;
		}
		_Transmit(frameA,11);
	}
}