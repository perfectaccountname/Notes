


#ifndef __UART_H__
#define __UART_H__

#include "include.h"
#include "led.h"

void uart_Init(void);
void uart_Start(void);
void uart_Stop(void);

uint8_t uart_bufferWrite( uint8_t data);
uint8_t uart_bufferRead(void);
uint8_t uart_bufferIsFull(void);
uint8_t uart_bufferIsEmpty(void);
void uart_bufferReset(void);

void uart_processData(void);
void uart_Send(uint16_t _ID, msgType _type, uint16_t _value);

#endif


