

#pragma interrupt INTIT isr_ITTimer
#pragma interrupt INTTM00 isr_TAU00Timer
#include "Timer.h"



/******************************************************************************
* Function Name: isr_TAU00Timer
* Description  : Interrupt service routine for TimerUnit0 Channel 0, 200ms cycle
*		 interrupt cycle 200ms :: send led and potentiometer status uart to pc
* Arguments    : none
* Return Value : none
******************************************************************************/
__interrupt static void isr_TAU00Timer(void){
	EI();
	uart_Send(1970, msgLED,led_getStatus());
	uart_Send(1970, msgADC,adc_getResult());
}


/******************************************************************************
* Function Name: isr_ITTimer
* Description  : Interrupt service routine for 12bit interval timer

* Arguments    : none
* Return Value : none
******************************************************************************/
__interrupt static void isr_ITTimer(void){
	//timer IT is not used.
}

/******************************************************************************
* Function Name: Timer_init
* Description  : initialize for 12-bit interval 
* Arguments    : none
* Return Value : none
******************************************************************************/
void Timer_IT_init(void){
	RTCEN = 1U;       	/* supply timer clock enable*/		// BIT PER0.BIT7 0xF00F0.7
    	ITMC &= IT_COUNT_STOP;  /* disable timer operation */ 		// REGS 0xFFF90, 16 BITS, BIT 15 ENABLE1/DISABLE 0. BIT 11-0 COUNT VALUE +1
    	ITMK  = 1U;       	/* disable timer interrupt */		// BIT MK1H.BIT2 0xFFFE7.2  INT services 1Dis/0En
    	ITIF = 0U;       	/* clear timer interrupt flag */	// BIT IF1H.BIT2 0XFFFE3.2  INT reqst gened 1Yes/0No
	
	// bit 4 WUTMMCK0 of OSMC and bit4 SWTON of optionbyte 000C0H set to 1, Low-speed on-chip oscillator clock activated
    	//OSMC = IT_FIL_SELECT;    	/* Select clock source: 		(FIL)Low-speed on-chip oscillator clock 15kHz*/
					// the clock source can be ethier FIL(15kHz) or Fsub(32.768kHz)
	// 2999+1 = 3000 CLK of Low-speed on-chip oscillator -> timer 200ms for update status to pc
    	ITMC = 326U;//IT_VALUE-1U; 		/* Configure timer data register */	// COUNT VALUE BIT0-BIT11 BIT15: ENABLE1/DISABLE0
	ITPR0 = 1U;		// PR[1:0] = 11, low priority
	ITPR1 = 1U;
}


/******************************************************************************
* Function Name: Timer_start
* Description  : start for 12-bit interval 
* Arguments    : none
* Return Value : none
******************************************************************************/
void Timer_IT_start(void)
{
    	ITMC = ITMC | IT_COUNT_STATED;  	/* enable timer operation     */	// BIT15: ENABLE1/DISABLE0
    	ITIF = 0U;       		/* clear timer interrupt flag */	// INT reqst gened 1Yes/0No
    	ITMK = 0U;       			/* enable timer interrupt     */	// INT services 1Dis/0En
}


/******************************************************************************
* Function Name: Timer_stop
* Description  : start for 12-bit interval 
* Arguments    : none
* Return Value : none
******************************************************************************/
void Timer_IT_stop(void)
{
    	ITMK = 1U;       		/* disable timer interrupt    */   	// INT services 1Dis/0En
    	ITIF = 0U;       		/* clear timer interrupt flag */	// INT reqst gened 1Yes/0No
    	ITMC = ITMC & IT_COUNT_STOP;  	/* disable timer operation    */
}





/******************************************************************************
* Function Name: Timer_TAU00_init
* Description  : use for update the led and potentiometer status, update rate = 150ms
*		 USE Timer Array Unit0 channel 0
* Arguments    : none
* Return Value : none
******************************************************************************/
void Timer_TAU00_init(void){
	// supply timer clock      		// BIT PER0.BIT0 0xF00F0.0
	TAU0EN = 1U;	
	// stop timer operation 		// 0xF01B4 bit 1, channel 0 ,1=stop Channel Stop register
	TT0L = 1U;    
	// disable timer interrupt 		// MK1. bit4  int service 1dis / 0En
	TMMK00 = 1U; 
	// clear timer interrupt flag 		// IF1. bit4  intrequest 0clear/1have request
    	TMIF00 = 0U;    
	// Timer Clock Select reg 16bit reg Fclk system = 32MHz
	TPS0 = 	TAU00_TPS_PRESCALE_62_5KHZ;	// select the prescaler	, operating clock = 62.5kHz
	// Timer Mode regs 16bit reg
	TMR00 = TAU00_TMR_MODE_ITCD_NOINTSTART|TAU00_TMR_STARTTRG_SW|TAU00_TMR_COUNTCLK_CKS000|TAU00_TMR_OPCLK_CK00;	
	// Priority level 2, use for update the led and potentiometer status, lower than RX and rx error
	TMPR000 = 0U;
	TMPR100 = 1U;
	// Timer data register : count value, 12500/62500  200ms
	TDR00 = TAU00_TDR_INTERVAL_VALUE-1U;
}


/******************************************************************************
* Function Name: Timer_TAU00_start
* Description  : Start timer unit 0 channel 0
* Arguments    : none
* Return Value : none
******************************************************************************/
void Timer_TAU00_start(void){
	TS0L = 1U;		// Enable TAU00	   read status TE
	TMIF00 = 0U;         	/* clear timer interrupt flag */
    	TMMK00 = 0U;    		/* enable timer interrupt */
}


/******************************************************************************
* Function Name: Timer_TAU00_stop
* Description  : Stop timer unit 0 channel 0
* Arguments    : none
* Return Value : none
******************************************************************************/
void Timer_TAU00_stop(void){
    	TMMK00 = 1U;    /* disable timer interrupt */
    	TMIF00 = 0U;    /* clear timer interrupt flag */
    	TT0L = 1U;    /* disable timer operation    */
}