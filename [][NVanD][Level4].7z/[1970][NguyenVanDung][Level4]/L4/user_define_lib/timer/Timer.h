

#ifndef __TIMER_H__
#define __TIMER_H__

#include "include.h"
#include "uart.h"
#include "adc.h"
#include "led.h"


void Timer_IT_init(void);
void Timer_IT_start(void);
void Timer_IT_stop(void);

void Timer_TAU00_init(void);
void Timer_TAU00_start(void);
void Timer_TAU00_stop(void);

#endif