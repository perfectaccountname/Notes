


#include "switch.h"


/***********************************************************************************************************************
* Function Name: sw_Init
* Description  : Switch 3 init
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void sw_Init(void){
	PM7 = GPIO_PIN5;
	PU7 = GPIO_PIN5;
}


/***********************************************************************************************************************
* Function Name: sw_getStatus
* Description  : get status of sw3, return TRUE when have falling edge else return false;
* Arguments    : None
* Return Value : TRUE or FALSE
***********************************************************************************************************************/
uint8_t sw_getStatus(void){
	static uint16_t state = 0U;		// P7_bit.no5 value 0xFF when button not press
	state = (state<<1)|P7_bit.no5|0x08000; // 15 consecutive bit0s after 1 bit1 -> falling edge 
	if(state == 0x0C000){
		return TRUE;
	}
	else{
		return FALSE;
	}
}