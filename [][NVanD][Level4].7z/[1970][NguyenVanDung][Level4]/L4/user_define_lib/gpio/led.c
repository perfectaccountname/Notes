


#include "led.h"


myledarray LEDarray = {0};

/***********************************************************************************************************************
* Function Name: led_Init
* Description  : This function initialize all the pins in corresponding port use for led
*		 and add all these led into an array of struct so it can use easier when turn on and off
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void led_Init(void){
	uint8_t i;
	// led2 p10 error display
	// led CW 62-42-63-43-64-44-65-45-66-152-67-101-41 << user control
	//	  3  4  5  6   7  8  9 10 11 12  13 14  15

	PM1 &= ~GPIO_PIN0; 
	
	// port6 led red .p62-> p67 , number 
	PM6 &= (uint8_t)(~(GPIO_PIN2|GPIO_PIN3|GPIO_PIN4|GPIO_PIN5|GPIO_PIN6|GPIO_PIN7)); // output== set to 0
	
	// port4 led green p41 -> p45 p152 p101
	PM4 &= ~(GPIO_PIN1|GPIO_PIN2|GPIO_PIN3|GPIO_PIN4|GPIO_PIN5);
	
	PM10 &= ~GPIO_PIN1;
	
	// by default p152 is use as analog pin.
	PM15 &= ~GPIO_PIN2;
	ADPC |= ADPC_FORMAT_DIGI_152_156;
	
	LEDarray.arrayStatus = 0U;
	
	// add ledlevel properties to ledStructure
	LEDarray.arr[12].port = PORT4;
	LEDarray.arr[12].ON = ~GPIO_PIN1;		// on *port &= ON,,, off = *port |= OFF
	LEDarray.arr[12].OFF = GPIO_PIN1;		// the on/off could truncate back to 1 var
  							// it basically set the 0 or 1 to led pos.
	LEDarray.arr[11].port = PORT10;			// if we want use less memory
	LEDarray.arr[11].ON = ~GPIO_PIN1;		// we can use only 1 led position properties and the port of led
	LEDarray.arr[11].OFF = GPIO_PIN1;
	
	LEDarray.arr[9].port = PORT15;
	LEDarray.arr[9].ON = ~GPIO_PIN2;		
	LEDarray.arr[9].OFF = GPIO_PIN2;
	
	for(i=0;i<6;i++){		//p62->p67 5 phantu o 0 2 4 6 8 10
		LEDarray.arr[i*2].port = PORT6;
		LEDarray.arr[i*2].ON = (uint8_t)(~(GPIO_PIN2<<i));		//GPIO_PIN2 0x04	
		LEDarray.arr[i*2].OFF = (uint8_t)(GPIO_PIN2<<i);
	}
	
	for(i=0;i<4;i++){		//p42->p45 4 phantu o 1 3 5 7
		LEDarray.arr[1+i*2].port = PORT4;
		LEDarray.arr[1+i*2].ON = (uint8_t)(~(GPIO_PIN2<<i));			
		LEDarray.arr[1+i*2].OFF = (uint8_t)(GPIO_PIN2<<i);
	}
	
	P6 = GPIO_PIN2|GPIO_PIN3|GPIO_PIN4|GPIO_PIN5|GPIO_PIN6|GPIO_PIN7;
	P4 = GPIO_PIN1|GPIO_PIN2|GPIO_PIN3|GPIO_PIN4|GPIO_PIN5;
	P10 = GPIO_PIN1;
	P15 = GPIO_PIN2;
	P1 = ~GPIO_PIN0;
}


/***********************************************************************************************************************
* Function Name: led_Control
* Description  : ON/OFF led, input led ID number and control state
* Arguments    : uint8_t _pos, uint8_t _state
* Return Value : None
***********************************************************************************************************************/
void led_Control(uint8_t _pos, uint8_t _state){
	uint8_t ledpos;
	ledpos = _pos - LEDOFFSET;
	if(_state == ON_STATE){
		(*LEDarray.arr[ledpos].port) &= LEDarray.arr[ledpos].ON;
	}
	else if(_state == OFF_STATE){
		(*LEDarray.arr[ledpos].port) |= LEDarray.arr[ledpos].OFF;
	}
}


/***********************************************************************************************************************
* Function Name: led_getStatus
* Description  : get the current state of led array
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
uint16_t led_getStatus(void){
	uint8_t i;
	uint8_t ledstatus;
	for(i=0;i<NUMBERLEDS;i++){
		//		port & mask ( use off as mask)
		//		if the result is OFF, then shift bit 0(0x0FFFE to current led pos
		ledstatus =  (*LEDarray.arr[i].port)&(LEDarray.arr[i].OFF);
		if(ledstatus == LEDarray.arr[i].OFF){
			LEDarray.arrayStatus &= ~(0x0001<<i) ;
		}
		else{	// ON shift bit 1(0x0001) to current led pos
			LEDarray.arrayStatus |= 0x0001<<i ;
		}
	}
	return (LEDarray.arrayStatus);
}


/***********************************************************************************************************************
* Function Name: led_Error
* Description  : ON/OFF led indication when system have error
* Arguments    : uint8_t _state
* Return Value : None
***********************************************************************************************************************/
void led_Error( uint8_t _state){
	if(_state == ON_STATE){
		P1 = GPIO_PIN0;	
	}
	else if(_state == OFF_STATE){
		P1 = ~GPIO_PIN0;	
	}	
}