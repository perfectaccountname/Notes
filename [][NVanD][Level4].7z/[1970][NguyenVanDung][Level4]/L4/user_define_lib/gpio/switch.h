


#ifndef __SWITCH_H__
#define __SWITCH_H__

#include "include.h"

void sw_Init(void);
uint8_t sw_getStatus(void);

#endif