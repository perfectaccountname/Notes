


#ifndef __LED_H__
#define __LED_H__

#include "include.h"

void led_Init(void);
void led_Control( uint8_t _pos, uint8_t _state);
uint16_t led_getStatus(void);
void led_Error( uint8_t _state);

#endif