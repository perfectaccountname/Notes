/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only 
* intended for use with Renesas products. No other uses are authorized. This 
* software is owned by Renesas Electronics Corporation and is protected under 
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING 
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT 
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE 
* AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR 
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE 
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software 
* and to discontinue the availability of this software.  By using this software, 
* you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2011, 2013 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : main.c
* Version      : 1.0.0
* Device(s)    : R5F104PJ
* Tool-Chain   : CA78K0R
* Description  : This file implements main function.
* Creation Date: 09-Sep-15
***********************************************************************************************************************/

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#pragma interrupt INTIT r_it_interrupt
#include "r_macro.h"
#include "r_spi_if.h"
#include "lcd.h"
#include "uart.h"
#include "sw.h"
#include "api.h"
#include "led.h"
#include "adc.h"
/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
unsigned int state = RUNNING;
extern unsigned int g_reset_buff;
volatile int G_elapsedTime=0;
unsigned int error_flag = 0;

unsigned int button;
unsigned int match;
unsigned int prev;
unsigned int read;
unsigned int final;
unsigned int prevfinal;
/***********************************************************************************************************************
Funtion declaration
***********************************************************************************************************************/
void LCD_Reset(void);
void LED_init(void);
void processing_uart(void);
/***********************************************************************************************************************
* Function Name: main
* Description  : This function implements main function.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void main(void)
{
    char str1[21] = "Embedded SW tranining";
    char str2[2]  = {0x0D, 0x0A};
    char str3[18] = "UART communication";
    unsigned char LCD_Line = LCD_LINE3;
    
    /* Initialize UART1 communication */
    Uart_Init();
    
    /* Initialize external interrupt - SW1 */
    INTC_Create();
    
    /* Initialize ADC module */
    ADC_Create();
    ADC_Set_OperationOn();
    
    /* Initialize Timer*/
    R_IT_Create();
    
	/* Initialize LEDs */
	LED_init();
	
    /* Enable interrupt */
    EI();
    
    LCD_Reset();
    
    /* Initialize SPI channel used for LCD */
    R_SPI_Init(SPI_LCD_CHANNEL);
	
    /* Initialize Chip-Select pin for LCD-SPI: P145 (Port 14, pin 5) */
    R_SPI_SslInit(
    SPI_SSL_LCD,             /* SPI_SSL_LCD is the index defined in lcd.h */
    (unsigned char *)&P14,   /* Select Port register */
    (unsigned char *)&PM14,  /* Select Port mode register */
    5,                       /* Select pin index in the port */
    0,                       /* Configure CS pin active state, 0 means active LOW level  */
    0                        /* Configure CS pin active mode, 0 means active per transfer */
    );
    
    /* Initialize LCD driver */
    InitialiseLCD();

    /* Clear LCD display */
    ClearLCD();
    
    /* Display information on the debug LCD.*/
    //DisplayLCD(LCD_LINE1, (uint8_t *)"UART 9600bps");
    //DisplayLCD(LCD_LINE2, (uint8_t *)"Interface");
    
    /* Start UART1 communication */
    Uart_Start();
    
    /* Start timer*/
    R_IT_Start();
    
    /* Start an A/D conversion */
    ADC_Start(); 
    
    /* Start external interrupt - SW1 */
    INTC10_Start();

    while (1U)
    {
	    //LED15 = LED_ON;
	if(G_elapsedTime >= 20)
	{
	G_elapsedTime=0;
		if (state == RUNNING)
		{
			/* Send LEDs status */
			send_led_status();
			/* Send ADC status */
			send_adc_status();
		      /* Check UART1 status and process */
		      processing_uart();
		}
	}
		else
		{
			;	
		}
    	}
}

void LCD_Reset(void)
{
    int i =0;
    /* Output a logic LOW level to external reset pin*/
    P13_bit.no0 = 0;
    for (i = 0; i < 1000; i++)
    {
        NOP();
    }

    /* Generate a raising edge by ouput HIGH logic level to external reset pin */
    P13_bit.no0 = 1;
    for (i = 0; i < 1000; i++)
    {
        NOP();
    }

    /* Output a logic LOW level to external reset pin, the reset is completed */
    P13_bit.no0 = 0;
}
/***********************************************************************************************************************
* Function Name: process
* Description  : This function processes LED and text.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void processing_uart(void)
{
	if(status == UART_RECEIVE_DONE)
      {
        
        status = 0;
	/* Replace the last element by NULL */
        rx_buff[UART_RX_BUFFER_LEN - 1] = '\0';
	uart_receive();		
        Uart_ClearBuff(&rx_buff[0], UART_RX_BUFFER_LEN - 1);
	g_reset_buff = 1;
      }
}
/***********************************************************************************************************************
* Function Name: LED_init
* Description  : This function initialize LEDs.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void LED_init(void)
{
	/* Initialize LEDs */
	PM1 = 0x00;
	P1 = 0x00;
	PM4 = 0x00;
	P4 = 0xFF; 
	PM6 = 0x00;
	P6 = 0xFF;
	PM10 = 0x00;
	P10 = 0xFF;
	PM15 = 0x00;
	P15 = 0xFF;
	ADPC = 0x0B; // P15.2 digital
}
/******************************************************************************
* Function Name: interrupts
* Description  : Interrupts when interrrupts timer =1
* Arguments    : none
* Return Value : none
******************************************************************************/
__interrupt static void r_it_interrupt(void)
{
    /* Start user code. Do not edit comment generated here */
    G_elapsedTime++;
    /* End user code. Do not edit comment generated here */
}
/******************************************************************************
End of file
******************************************************************************/
