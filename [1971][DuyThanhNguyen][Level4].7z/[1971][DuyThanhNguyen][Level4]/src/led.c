/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only 
* intended for use with Renesas products. No other uses are authorized. This 
* software is owned by Renesas Electronics Corporation and is protected under 
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING 
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT 
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE 
* AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR 
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE 
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software 
* and to discontinue the availability of this software.  By using this software, 
* you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2011, 2013 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : led.c
* Version      : 1.0.0
* Device(s)    : R5F104PJ
* Tool-Chain   : CA78K0R
* Description  : This file implements for swtich.
* Creation Date: 19-Apr-17
***********************************************************************************************************************/

/******************************************************************************
Pragma directive
******************************************************************************/


/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_macro.h"
#include "iodefine.h"
#include "iodefine_ext.h"
#include "led.h"
#include "uart.h"

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
//extern float prt;
//extern int pos;
//extern float value[];
//extern uint8_t *port[];
//extern uint8_t led_on[];
//extern uint8_t led_off[];
//extern int numline;
//extern int error_status;
char g_send_led[13];
char g_data_led[4];
/***********************************************************************************************************************
Private variables and functions
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: turn_led
* Description  : This function turn on LEDs.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void turn_led(int led_pos, int led_status)
{
	switch (led_pos)
	{
		case 2:
		LED2 = led_status;
		break;
		case 3:
		LED3 = led_status;
		break;
		case 4:
		LED4 = led_status;
		break;
		case 5:
		LED5 = led_status;
		break;
		case 6:
		LED6 = led_status;
		break;
		case 7:
		LED7 = led_status;
		break;
		case 8:
		LED8 = led_status;
		break;
		case 9:
		LED9 = led_status;
		break;
		case 10:
		LED10 = led_status;
		break;
		case 11:
		LED11 = led_status;
		break;
		case 12:
		LED12 = led_status;
		break;
		case 13:
		LED13 = led_status;
		break;
		case 14:
		LED14 = led_status;
		break;
		case 15:
		LED15 = led_status;
		break;
		default:
		break;
	}
}
/***********************************************************************************************************************
* Function Name: send_led_status
* Description  : This function check valid of data received to turn on -off led.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void send_led_status (void)
{
	g_data_led[0]=0x0000;
	g_data_led[1]=0x0000;
	g_data_led[2]=0x0000;
	g_data_led[3]=0x0000;

	g_data_led[0]= (g_data_led[0]|(LED3<<0)|(LED4<<1)|(LED5<<2)|(LED6<<3))^0x0F;
	g_data_led[1]= (g_data_led[1]|(LED7<<0)|(LED8<<1)|(LED9<<2)|(LED10<<3))^0x0F;
	g_data_led[2]= (g_data_led[2]|(LED11<<0)|(LED12<<1)|(LED13<<2)|(LED14<<3))^0x0F;
	g_data_led[3]= (g_data_led[3]|(LED15<<0))^0x01;

	g_send_led[0]='$';
	g_send_led[1]='1';
	g_send_led[2]='9';
	g_send_led[3]='6';
	g_send_led[4]='4';
	g_send_led[5]=',';
	g_send_led[6]='L';
	g_send_led[7] =(char)(g_data_led[3] >= 0x0A ? (g_data_led[3]+0x37) : (g_data_led[3]+0x30));
	g_send_led[8] =(char)(g_data_led[2] >= 0x0A ? (g_data_led[2]+0x37) : (g_data_led[2]+0x30));
	g_send_led[9] =(char)(g_data_led[1] >= 0x0A ? (g_data_led[1]+0x37) : (g_data_led[1]+0x30));
	g_send_led[10]=(char)(g_data_led[0] >= 0x0A ? (g_data_led[0]+0x37) : (g_data_led[0]+0x30));
	g_send_led[11]='^';
	g_send_led[12]='\0';

	/*transmit led status*/
	Uart_Transmit(g_send_led,13);
}
/***********************************************************************************************************************
* Function Name: check_led_status
* Description  : This function check valid of data received to turn on -off led.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
//void check_led_status(char *buff)
//{
//	int led_number =0;
//	int i = 0;
//	char temp[3] ={'\0','\0','\0'};
//	numline = 0;
//	if (buff[1] =='L')
//	{
//		/*take number of led*/
//		for (i = 3 ; buff[i] != ','; i++)
//		{
//			temp[i-3] = buff[i];
//		}
//		led_number = atoi(temp);
//		led_number = led_number -3;
//		/*check valid of led number*/
//		if (led_number < 0 | led_number > 12)
//		{
//			display_msg_error();
//		}
//		/*check led state value */
//		else if ((buff[i+1] !='1')&&(buff[i+1] !='0'))
//		{
//			display_msg_error();
//		}
//		else
//		{
//			
//			if(buff[i+1] =='1')
//			{
//				/*turn on led*/
//				*port[led_number ] &= _value_on[led_number];	
//			}
//			else if (buff[i+1] =='0')
//			{
//				/*turn off led*/
//				*port[led_number] |= _value_off[led_number];	
//			}
//			/*asign flag value*/
//			error_status = NO_ERR;
//			P1_bit.no0 = 0;
//		}
//	}
//}

/******************************************************************************
End of file
******************************************************************************/
