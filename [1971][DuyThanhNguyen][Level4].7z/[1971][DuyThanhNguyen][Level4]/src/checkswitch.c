
#include "checkswitch.h"    /* Standard IO library: sprintf */
#include "ChatDel.h"
#include "uart.h"
#include "led.h"
#include "lcd.h"

unsigned int j, k;
unsigned int check;

unsigned int enable_switch;

extern unsigned int button;
extern unsigned int match;
extern unsigned int prev;
extern unsigned int read;
extern unsigned int final;
extern unsigned int prevfinal;
extern int state;
extern char temp_receive[UART_RX_BUFFER_LEN];

void checkswitch (void);
/******************************************************************************
* Function Name: checkswitch
* Description  : check Switch and reduce chattering
* Arguments    : none
* Return Value : none
******************************************************************************/
//unsigned int getswitch(){
//	
//	check = PRESS;
//	switch(check){
//		
//		case SW3:
//			if(enable_switch == 1){
//				delay();
//				enable_switch = 0;
//				check = SW3;
//			}else {
//				check = 0;
//			}
//			break;
//			
//		default:
//			delay();
//			enable_switch = 1;
//			check = 0;
//			break;
//	}
//	
//	return check;
//}
/******************************************************************************
* Function Name: delay
* Description  : delay for reduce noise 
* Arguments    : none
* Return Value : none
******************************************************************************/
//void delay(){
//	for (j = 0; j < 300; j++){
//		for (k = 0; k < 2000; k++){
//			if(PRESS != 0x07){
//				break;
//			}
//		}
//	}
//}
/******************************************************************************
* Function Name: checkswitch
* Description  : check Switch and reduce chattering
* Arguments    : none
* Return Value : none
******************************************************************************/
void checkswitch (void)
{
    button = ChatDel();
    //A button is pressed;
    if((button != 0) && (button != 0x70))
    {
	// Reset   
        if (button == SWT3)
        {
		if (state != NO_ERROR)
		{
			   int i;
			   /*clear LCD*/
			   ClearLCD();
			   /*Reset error_flag*/
			   error_flag = NO_ERROR;
			   /*Turn off LED 2*/
			   P1_bit.no0 = 0;
			   /*Reset receiving data buffer */
			   for (i=0; i<9 ;i++)
			   {
			   Uart_ClearBuff(receive_data[i], UART_RX_BUFFER_LEN - 1);
			   }
			   /* Reset temp variable used to display data*/
			   Uart_ClearBuff(&temp_receive[0], UART_RX_BUFFER_LEN - 1);
			   /*Reset led status*/			
			   led_status_1.status_led =0x0000;
			   /*Turn off all led*/
			   P6 = 0xff;
			   P4 = 0xff;
			   P10_bit.no1 =1;
			   P15_bit.no2 =1;
			   /*Reset index variable*/
			   numb =0;
			   /*Reset register check error of uart_error*/
			   SIR03 = 0x07;
		}
        }
    }
}
