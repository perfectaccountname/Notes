
#include "r_macro.h"  /* System macro and standard type definition */


#define SWT3 0x20

void checkswitch (void);