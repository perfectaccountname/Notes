/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_macro.h"  /* System macro and standard type definition */
#include "r_spi_if.h" /* SPI driver interface */
#include "lcd.h"      /* LCD driver interface */
#include "Port.h"
#include <string.h>
#include "ChatDel.h"
#include "checkswitch.h"
#include "record.h"
/******************************************************************************
Macro definitions
******************************************************************************/
#define RUNNING 1 // Running...
#define PAUSED 0 // Paused...

#define MAX 20

#define SWT1 0x40
#define SWT2 0x10
#define SWT3 0x20
#define SWT12 0x50

#define PRT_RUNNING "Running...  " // Running...
#define PRT_PAUSED "Pausing...  " // Paused...
#define PRT_NOREC "No record   " // No record
#define PRT_FIRSTREC "First record" // First record
#define PRT_LASTREC "Last record " // Last record

#define FIRSTREC 1
#define LASTREC 2
#define NOREC 3
#define YESSCROLL 4

/******************************************************************************
Imported global variables and functions (from other files)
******************************************************************************/
extern unsigned int button;
extern unsigned int state;
extern int sec;
extern int min;
extern int csec;
extern char* string_shown_on_lcd[10];
extern unsigned int scroll;
extern unsigned int scroll_flag;
extern unsigned int rec_flag;
extern unsigned int displayrec_flag;
extern unsigned int scrollstate;
extern String data[21];
extern int tail;
extern int head;
extern int num;
//extern volatile int G_elapsedTime; 
//int temptime;
//extern int move_flag;
/******************************************************************************
Private global variables and functions
******************************************************************************/

/******************************************************************************
* Function Name: checkswitch
* Description  : Check which switch was pressed. Change state.
* Arguments    : none
* Return Value : none
******************************************************************************/
void checkswitch (void)
{
    button = ChatDel();
    //A button is pressed;
    if((button != 0) && (button != 0x70)){
	    
	// Scroll up    
        if (button == SWT1)
        {
		checkscroll();
		if (scroll_state == YESSCROLL)
		{
			scroll_up();
		}
        }
	
	// Scroll down
        else if (button == SWT2)
        {
		checkscroll();
		if (scroll_state == YESSCROLL)
		{
			scroll_down();
		}
        }

        else if (button == SWT3)
        {
            // Record
            if (state == RUNNING)
            {
		insertCirQueue(min, sec, csec);
            }

            // Running
            else if (state == PAUSED)
            {
		DisplayLCD(LCD_LINE1, PRT_RUNNING);
                state = RUNNING; // Counting
		//G_elapsedTime = temptime;
            }
	}
	
	else if (button == SWT12)
	{
		//Paused
		if (state == RUNNING)
		{
			DisplayLCD(LCD_LINE1, PRT_PAUSED);
	                state = PAUSED; // Paused
			//temptime = G_elapsedTime;
		}
		
		//Reset
		else if (state == PAUSED)
		{
			memset(&data[0].str[0],0u,21*25);
			tail = 0;
			num = 0;
			head = 0;
	                sec = 0;
	                min = 0;
			csec = 0;
			ClearLCD();
			DisplayLCD(LCD_LINE1, PRT_PAUSED);
	                state = PAUSED; // Paused
			sprintf(string_shown_on_lcd, "%0.2d:%0.2d:%0.2d", min, sec, csec);
	                DisplayLCD(LCD_LINE2, string_shown_on_lcd);
		}
	}
    }
}