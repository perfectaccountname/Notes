/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "iodefine.h"
/******************************************************************************
Exported global variables and functions (to be accessed by other files)
******************************************************************************/
extern unsigned int scroll;
extern unsigned int scroll_state;
void shift(void);
typedef struct _String
{
	char str[25];
}String;

/***********************************************************************************************************************
Function prototypes
***********************************************************************************************************************/
void insertCirQueue(int min, int sec, int csec);
void scroll_up(void);
void scroll_down(void);
void displayRec(void);
void checkscroll(void);