/******************************************************************************
Includes   <System Includes> , "Project Includes"
******************************************************************************/
#pragma sfr
#include "r_macro.h"  /* System macro and standard type definition */
#include "r_spi_if.h" /* SPI driver interface */
#include "lcd.h"      /* LCD driver interface */
#include "Port.h"
#include "stdio.h"
#include <string.h>
#include "ChatDel.h"
#include "checkswitch.h"
#include "timer.h"
#include "record.h"
/******************************************************************************
Macro definitions
******************************************************************************/
#define MAX 20


#define FIRSTREC 1
#define LASTREC 2
#define NOREC 3
#define YESSCROLL 4

#define PRT_RUNNING "Running...  " // Running...
#define PRT_PAUSED "Pausing...  " // Paused...
#define PRT_NOREC "No record   " // No record
#define PRT_FIRSTREC "First record" // First record
#define PRT_LASTREC "Last record " // Last record

#define SWT1 0x40
#define SWT2 0x10
#define SWT3 0x20
#define SWT12 0x50
/******************************************************************************
Imported global variables and functions (from other files)
******************************************************************************/
extern unsigned int button;
extern int temp;
extern unsigned int flag2secs;
extern unsigned int scroll_state;
extern int k;
/******************************************************************************
Exported global variables and functions (to be accessed by other files)
******************************************************************************/
int tail = 0;
int num = 0;
int head = 0;
/******************************************************************************
Private global variables and functions
******************************************************************************/
int i;
int y;
unsigned int scroll;
String data[21];
/******************************************************************************
* Function Name: insertCirQueue
* Description  : To insert and  display items into array.
* Arguments    : Time values
* Return Value : none
******************************************************************************/
void insertCirQueue( int min, int sec, int csec)
{
	num++;
	sprintf(data[head].str, "#%0.2d:%0.2d:%0.2d:%0.2d",num, min, sec, csec);
	head++;
	if (head > 21)
	{
		head = 21;
	}
	if (head < 7)
	{
		y = 1;
		for (i = tail; i <= head;i++)
		{
			DisplayLCD((unsigned char)(LCD_LINE2 + y*8),(uint8_t *)data[i].str);
			y++;
		}
	}
	if (head >= 7 && head <= 20)
	{
		if(head - tail == 7)
		tail++;
		y=1;
		if (tail >= 14)
		{
			tail = 14;
		}
		for (i = tail; i <= tail + 6; i++)
		{
			DisplayLCD((unsigned char)(LCD_LINE2 + y*8),(uint8_t *)data[i].str);
			y++;
		}
	}
	if (head > 20)
	{
		y=1;
		shift();
		strcpy(data[19].str,data[20].str);
		if((0 < tail)&&(tail < 14))
		{
			tail--;
		}
		for (i = tail; i <= tail + 6;i++)
		{
			DisplayLCD((unsigned char)(LCD_LINE2 + y*8),(uint8_t *)data[i].str);
			y++;
		}
		head = 20;
	}
}
/******************************************************************************
* Function Name: shift
* Description  : shift aand insert new element into array.
* Arguments    : Pointer q, inserted values
* Return Value : none
******************************************************************************/
void shift(void)
{
	int i;
	for(i = 0 ;i < 19;i++)
	{ 
		strcpy(data[i].str,data[i+1].str);
	}
}

/******************************************************************************
* Function Name: scroll_up
* Description  : Scroll up the list
* Arguments    : none
* Return Value : none
******************************************************************************/
void scroll_up(void)
{	
	int i,y;
	i=0;
	y=1;
	tail--;
	if (tail <= 0)
	{
		tail = 0;
		temp = state;
		flag2secs = 1;
		DisplayLCD(LCD_LINE1 ,PRT_FIRSTREC);	
		scroll_state = FIRSTREC;
	}
	for (i = tail; i <= tail + 6; i++)
	{
		DisplayLCD((unsigned char)(LCD_LINE2 + y*8),(uint8_t *)data[i].str);
		y++;
	}	
}

/******************************************************************************
* Function Name: scroll_down
* Description  : Scroll down the list
* Arguments    : none
* Return Value : none
******************************************************************************/
void scroll_down()
{ 
	int i,y;
	i=0;
	y=1;
	if(head - tail > 6)
	tail++;
	else if(head - tail <= 6)
	{	temp = state;
		flag2secs = 1;
		DisplayLCD(LCD_LINE1 ,PRT_LASTREC);	
		scroll_state = LASTREC;
	}
	
	if (tail >= 14)
	{
		tail = 14;
	}
	
	for (i = tail; i <= tail + 6;i++)
	{
		DisplayLCD((unsigned char)(LCD_LINE2 + y*8),(uint8_t *)data[i].str);
		y++;
	}
}

/******************************************************************************
* Function Name: checkscroll
* Description  : Check if able to scroll or not
* Arguments    : none
* Return Value : none
******************************************************************************/

void checkscroll(void)
{ 
	if (head == 0 && (button == SWT2 || button == SWT1))
	{
		DisplayLCD(LCD_LINE1, PRT_NOREC);
		scroll_state = NOREC;
		flag2secs = 1;
		k = 0;
	}
	
	else if((head < 7) && (button == SWT2))
	{
		DisplayLCD(LCD_LINE1, PRT_LASTREC);
		scroll_state = LASTREC;
		flag2secs = 1;
		k = 0;
	}
	
	else if((head < 7) && (button == SWT1))
	{
		DisplayLCD(LCD_LINE1, PRT_FIRSTREC);
		scroll_state = FIRSTREC;
		flag2secs = 1;
		k = 0;
	}

	else scroll_state = YESSCROLL;
}