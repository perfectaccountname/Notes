/******************************************************************************
* DISCLAIMER

* This software is supplied by Renesas Electronics Corporation and is only 
* intended for use with Renesas products. No other uses are authorized.

* This software is owned by Renesas Electronics Corporation and is protected under 
* all applicable laws, including copyright laws.

* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES 
* REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, 
* INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
* PARTICULAR PURPOSE AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY 
* DISCLAIMED.

* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES 
* FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS 
* AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

* Renesas reserves the right, without notice, to make changes to this 
* software and to discontinue the availability of this software.  
* By using this software, you agree to the additional terms and 
* conditions found by accessing the following link:
* http://www.renesas.com/disclaimer
******************************************************************************/
/* Copyright (C) 2015 Renesas Electronics Corporation. All rights reserved.  */
/******************************************************************************	
* File Name    : main.c
* Version      : 1.00
* Device(s)    : 
* Tool-Chain   : 
* H/W Platform : 
* Description  : 
******************************************************************************
* History : DD.MM.YYYY Version Description
*         : 03.07.2015 1.00    First Release
******************************************************************************/


/******************************************************************************
Includes   <System Includes> , "Project Includes"
******************************************************************************/
#pragma sfr
#pragma interrupt INTIT r_it_interrupt
#include "r_macro.h"  /* System macro and standard type definition */
#include "r_spi_if.h" /* SPI driver interface */
#include "lcd.h"      /* LCD driver interface */
#include "Port.h"
#include "stdio.h"
#include <string.h>
#include "ChatDel.h"
#include "checkswitch.h"
#include "timer.h"
#include "record.h"

/******************************************************************************
Typedef definitions
******************************************************************************/
volatile int G_elapsedTime = 0;   // Timer Counter
/******************************************************************************
Macro definitions
******************************************************************************/
#define RUNNING 1 // Running...
#define PAUSED 0 // Paused...

#define PRT_RUNNING "Running...  " // Running...
#define PRT_PAUSED "Pausing...  " // Paused...
#define PRT_NOREC "No record   " // No record
#define PRT_FIRSTREC "First record" // First record
#define PRT_LASTREC "Last record " // Last record

#define MAX 20

#define NOMOVE 0
#define FIRSTREC 1
#define LASTREC 2
#define NOREC 3
#define YESSCROLL 4

#define SWT1 0x40
#define SWT2 0x10
#define SWT3 0x20
#define SWT12 0x50


#define DOWN 1
#define UP 2


#define REC 2

#define EMPTY 1
#define NOTEMPTY 0

#define FULL 1
#define NOTFULL 0
/******************************************************************************
Imported global variables and functions (from other files)
******************************************************************************/

/******************************************************************************
Exported global variables and functions (to be accessed by other files)
******************************************************************************/
int sec = 0;
int min = 0;
int csec = 0;
char * string_shown_on_lcd[10];
unsigned int match = 0;
unsigned int prev = 0x70;
unsigned int read = 0x70;
unsigned int final = 0;
unsigned int prevfinal = 0;
unsigned int button = 0;
unsigned int state = PAUSED;
unsigned int flag2secs = 0;
unsigned int scroll_state = 0;
int temp;
int k=0;

/******************************************************************************
Private global variables and functions
******************************************************************************/
void r_main_userinit(void);
void checkswitch(void);
void wait(int mode);
void insertCirQueue(int min, int sec, int tencentisec);

/******************************************************************************
* Function Name: main
* Description  : Main program
* Arguments    : none
* Return Value : none
******************************************************************************/
void main(void)
{
	/* Initialize user system */
	r_main_userinit();

	/* Clear LCD display */
	ClearLCD();
	
	R_IT_Create();
	R_IT_Start();

	/* Print message to the first line of LCD */
	//DisplayLCD(LCD_LINE1, (uint8_t *)"Hello World!");

	DisplayLCD(LCD_LINE1, PRT_PAUSED);
	sprintf(string_shown_on_lcd, "%0.2d:%0.2d:%0.2d", min, sec, csec);
	DisplayLCD(LCD_LINE2, string_shown_on_lcd);
	/* Main loop - Infinite loop */
	while (1)
	{
		checkswitch();
		if (state == RUNNING)
		{
			{		
				//wait(0);
				//G_elapsedTime++;
				if (G_elapsedTime >= 1)
				{
					csec = csec + 10;
					G_elapsedTime = 0;
					if (csec > 90)
					{
						csec = 0;
						sec++;
						if (sec > 59)
						{
							sec = 0;
							min++;
						}
					}
					sprintf(string_shown_on_lcd, "%0.2d:%0.2d:%0.2d", min, sec, csec);
		                	DisplayLCD(LCD_LINE2, string_shown_on_lcd);
				}
			}
		}
		if(scroll_state == FIRSTREC && flag2secs == 0)
		{
			if(state==RUNNING)
			DisplayLCD(LCD_LINE1, PRT_RUNNING);
			else if(state == PAUSED)
			DisplayLCD(LCD_LINE1, PRT_PAUSED);
			scroll_state=NOMOVE;
		}
		
		else if(scroll_state == LASTREC && flag2secs == 0)
		{
			if(state == RUNNING)
			DisplayLCD(LCD_LINE1, PRT_RUNNING);
			else if(state == PAUSED)
			DisplayLCD(LCD_LINE1, PRT_PAUSED);
			scroll_state=NOMOVE;
		}
		
		else if(scroll_state == NOREC && flag2secs == 0)
		{
			if(state == RUNNING)
			DisplayLCD(LCD_LINE1, PRT_RUNNING);
			else if(state == PAUSED)
			DisplayLCD(LCD_LINE1, PRT_PAUSED);
			scroll_state=NOMOVE;
		}
	}
}


/******************************************************************************
* Function Name: wait
* Description  : User initialization routine
* Arguments    : C timer or Assembly
* Return Value : none
******************************************************************************/
void wait(int mode)
{
	if (mode == 1)
	{
		unsigned long i = 22000;
		while (i!=0) i--;
	}
	else
	{
		Wait1CentiSecond();
	}
}


/******************************************************************************
* Function Name: r_main_userinit
* Description  : User initialization routine
* Arguments    : none
* Return Value : none
******************************************************************************/
void r_main_userinit(void)
{
	uint16_t i;

	/* Enable interrupt */
	EI();

	/* Output a logic LOW level to external reset pin*/
	P13_bit.no0 = 0;
	for (i = 0; i < 1000; i++)
	{
		NOP();
	}

	/* Generate a raising edge by ouput HIGH logic level to external reset pin */
	P13_bit.no0 = 1;
	for (i = 0; i < 1000; i++)
	{
		NOP();
	}

	/* Output a logic LOW level to external reset pin, the reset is completed */
	P13_bit.no0 = 0;

	/* Initialize SPI channel used for LCD */
	R_SPI_Init(SPI_LCD_CHANNEL);

	/* Initialize Chip-Select pin for LCD-SPI: P145 (Port 14, pin 5) */
	R_SPI_SslInit(
		SPI_SSL_LCD,             /* SPI_SSL_LCD is the index defined in lcd.h */
		(unsigned char *)&P14,   /* Select Port register */
		(unsigned char *)&PM14,  /* Select Port mode register */
		5,                       /* Select pin index in the port */
		0,                       /* Configure CS pin active state, 0 means active LOW level  */
		0                        /* Configure CS pin active mode, 0 means active per transfer */
	);

	/* Initialize LCD driver */
	InitialiseLCD();
}

/******************************************************************************
End of file
******************************************************************************/

__interrupt static void r_it_interrupt(void)
{
    /* Start user code. Do not edit comment generated here */
    	int i;
	G_elapsedTime++;
	if (flag2secs == 1)
	{
		k=k+10;
		if(k>200)
		{
		state = temp;
		k=0;
		flag2secs=0;
		}
	}
    
    /* End user code. Do not edit comment generated here */
} 