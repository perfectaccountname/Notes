/***********************************************************************************************************************
Pre-processor directive for interrupt
***********************************************************************************************************************/
#pragma interrupt INTWDTI WDG_Interval_Timer

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_macro.h"
#include "WatchdogTimer.h"

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
unsigned int WDGFlag = 0;

/***********************************************************************************************************************
* Function Name: WDGSetting
* Description  : This function set up Watchdog operation
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void WDGSetting(void)
{
  /* Disable interval WDG interrupt */
  MK0L |= 0x01;
  
  /* Clear interrupt request flag */
  IF0L &= 0xFE;
  
  /* Setting priority */
  PR00L |= 0x01;
  PR10L |= 0x01;
  
  /* Enable interval WDG interrupt */
  MK0L &= 0xFE;
}

/***********************************************************************************************************************
* Function Name: ResetWDG
* Description  : This function writes activation key to Watchdog register.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void ResetWDG(void)
{
  WDTE = 0xACU;
}

/***********************************************************************************************************************
* Function Name: WDG_Interval_Timer
* Description  : This function is Wachdog 75% interrupt handler
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
__interrupt void WDG_Interval_Timer(void)
{
  /* Toggle ORANGE LED*/
  P4 ^= 0x02;

  /* Increase WDG flag */
  WDGFlag++;
}
