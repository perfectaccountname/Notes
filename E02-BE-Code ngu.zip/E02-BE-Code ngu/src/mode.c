/******************************************************************************
* DISCLAIMER

* This software is supplied by Renesas Electronics Corporation and is only 
* intended for use with Renesas products. No other uses are authorized.

* This software is owned by Renesas Electronics Corporation and is protected under 
* all applicable laws, including copyright laws.

* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES 
* REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, 
* INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
* PARTICULAR PURPOSE AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY 
* DISCLAIMED.

* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES 
* FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS 
* AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

* Renesas reserves the right, without notice, to make changes to this 
* software and to discontinue the availability of this software.  
* By using this software, you agree to the additional terms and 
* conditions found by accessing the following link:
* http://www.renesas.com/disclaimer
******************************************************************************/
/* Copyright (C) 2015 Renesas Electronics Corporation. All rights reserved.  */
/******************************************************************************	
* File Name    : timer.c
* Version      : 1.00
* Device(s)    : 
* Tool-Chain   : 
* H/W Platform : 
* Description  : 
******************************************************************************
* History : DD.MM.YYYY Version Description
*         : 01.07.2015 1.00    First Release
******************************************************************************/


/******************************************************************************
Includes   <System Includes> , "Project Includes"
******************************************************************************/
#include "r_macro.h"
#include "def.h"
#include "lcd.h"
#include "switch.h"
#include "timer.h"
/******************************************************************************
Typedef definitions
******************************************************************************/

/******************************************************************************
Macro definitions
******************************************************************************/
#define running_flag	(flag & 0x01)		//Take bit 0 value of flag 
#define pause_flag	((flag>>1) & 0x01)	//Take bit 1 value of flag
#define not_running_flag (flag^0x01)		//couting_flag = ! couting_flag
#define not_pause_flag	(flag^0x02)		//pause_flag = ! pause_flag

/******************************************************************************
Imported global variables and functions (from other files)
******************************************************************************/

/******************************************************************************
Exported global variables and functions (to be accessed by other files)
******************************************************************************/

/******************************************************************************
* Function Name: func_DisplayLCD
* Description  : Display minutes and seconds to lcd screen
* Arguments    : minute and second
* Return Value : none
******************************************************************************/

void func_DisplayLCD(uint8_t minute, uint8_t second, uint8_t centisecond){
	sprintf(text_lcd,"  %d:%d:%d  ",minute, second, centisecond);
	DisplayLCD(LCD_LINE2,text_lcd);
}



void func_Display_Scroll(uint8_t pos){
		
		if((record_minute[pos]!=0)||(record_second[pos]!=0)||(record_centisecond[pos]!=0)){	
			if (pos<=record){
				sprintf(text_lcd," #%d %d:%d:%d  ",pos,record_minute[pos],record_second[pos],record_centisecond[pos]);
				DisplayLCD(LCD_LINE3,text_lcd);
			}
		}
		if((record_minute[pos+1]!=0)||(record_second[pos+1]!=0)||(record_centisecond[pos+1]!=0)){	
			if (pos+1<=record){
				sprintf(text_lcd," #%d %d:%d:%d  ",pos+1,record_minute[pos+1],record_second[pos+1],record_centisecond[pos+1]);
				DisplayLCD(LCD_LINE4,text_lcd);
			}
		}
		if((record_minute[pos+2]!=0)||(record_second[pos+2]!=0)||(record_centisecond[pos+2]!=0)){	
			if (pos+2<=record){
				sprintf(text_lcd," #%d %d:%d:%d  ",pos+2,record_minute[pos+2],record_second[pos+2],record_centisecond[pos+2]);
				DisplayLCD(LCD_LINE5,text_lcd);
			}
		}
		if((record_minute[pos+3]!=0)||(record_second[pos+3]!=0)||(record_centisecond[pos+3]!=0)){	
			if (pos+3<=record){
				sprintf(text_lcd," #%d %d:%d:%d  ",pos+3,record_minute[pos+3],record_second[pos+3],record_centisecond[pos+3]);
				DisplayLCD(LCD_LINE6,text_lcd);
			}
		}
		if((record_minute[pos+4]!=0)||(record_second[pos+4]!=0)||(record_centisecond[pos+4]!=0)){	
			if (pos+4<=record){
				sprintf(text_lcd," #%d %d:%d:%d  ",pos+4,record_minute[pos+4],record_second[pos+4],record_centisecond[pos+4]);
				DisplayLCD(LCD_LINE7,text_lcd);
			}
		}
		if((record_minute[pos+5]!=0)||(record_second[pos+5]!=0)||(record_centisecond[pos+5]!=0)){	
			if (pos+5<=record){
				sprintf(text_lcd," #%d %d:%d:%d  ",pos+5,record_minute[pos+5],record_second[pos+5],record_centisecond[pos+5]);
				DisplayLCD(LCD_LINE8,text_lcd);
			}
		}

}

/******************************************************************************
* Function Name: init_mode
* Description  : Intitial value and dislay the first time after reset
* Arguments    : none
* Return Value : none
******************************************************************************/
void init_mode(){
uint8_t i;
	g_time.centisecond=0;
	g_time.second =0;
	g_time.minute =0;
	p_time.minute =0;
	p_time.second =0;
	p_time.centisecond=0;
	
	record = 1;
	pos_scroll=1;
	for(i=0;i<=20;i++){
		record_minute[i]=0;
		record_second[i]=0;
		record_centisecond[i]=0;
	}
	
	/* counting_flag = 0; pause_flag = 1, setting_flag = 1; */
	flag = 0x06;
	
	/* Display the first time after reset */
	DisplayLCD(LCD_LINE1,(const uint8_t *)"PAUSING...");
	DisplayLCD(LCD_LINE2,(const uint8_t *)"   0:0:0");
	timer_init();
}

/******************************************************************************
* Function Name: count_down_mode
* Description  : Excute counting down mode
* Arguments    : none
* Return Value : none
******************************************************************************/

void running_mode(){
	uint8_t temp;
	/* Display time to LCD when time change in running_mode */	
	if(first_record==1){
		if(g_time.second>temp_record+2){
			DisplayLCD(LCD_LINE1,(const uint8_t *)"RUNNING...");
			first_record=0;
		}
	}
	if(last_record==1){
		if(g_time.second>temp_record+2){
			DisplayLCD(LCD_LINE1,(const uint8_t *)"RUNNING...");
			last_record=0;
		}
	}
	if((g_time.centisecond!=p_time.centisecond)||(g_time.second!=p_time.second)||(g_time.minute!=p_time.minute)){
		func_DisplayLCD(g_time.minute,g_time.second,g_time.centisecond);
		p_time.centisecond = g_time.centisecond;
		p_time.second = g_time.second;
		p_time.minute = g_time.minute;
	}
	check_switch();
	if(count==100){
		count=0;
		g_time.centisecond+=10;
	}
	if(g_time.centisecond==100){
		g_time.centisecond=0;
		g_time.second++;
	}
	if(g_time.second==60){
		g_time.second=0;
		g_time.minute++;
	}	

}

/******************************************************************************
* Function Name: setting_mode
* Description  : Excute setting mode
* Arguments    : none
* Return Value : none
******************************************************************************/
void pause_mode(){
	static int temp=0;
	/* Check switch which is pressed */
	
	if(count==100){
		count=0;
		temp++;
	}
	if(temp>=25){
		DisplayLCD(LCD_LINE1,(const uint8_t *)"PAUSING...");
		timer_stop();
		count=0;
		temp=0;
	}
	check_switch();
	/* Display time to LCD when time change in count_down_mode */	
	
}
/******************************************************************************
Private global variables and functions
******************************************************************************/

/******************************************************************************
End of file
******************************************************************************/

